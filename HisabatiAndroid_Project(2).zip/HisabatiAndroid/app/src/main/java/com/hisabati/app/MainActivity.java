package com.hisabati.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.security.MessageDigest;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    String current = "الرئيسية";
    final String[] sections = {"الخزينة","المصروفات","الخضر والفواكه","اللحوم والدجاج","المواد الغذائية","الخياطة","الديون"};
    final String[] vegetables = {"بطاطا","طماطم","بصل","جزر","فلفل","كوسة","خيار","خس","ثوم","باذنجان","قرنبيط","ملفوف","فاصولياء","بازلاء","سبانخ"};
    final String[] fruits = {"تفاح","موز","برتقال","ليمون","إجاص","عنب","فراولة","خوخ","مشمش","رمان","تمر","بطيخ","شمام","كيوي"};
    final String[] meats = {"لحم بقر","لحم غنم","لحم ماعز","دجاج كامل","صدر دجاج","أفخاذ دجاج","أجنحة","لحم مفروم","أحشاء"};
    final String[] foods = {"حليب ومشتقاته","زيت وزبدة","سكر وملح","أرز وعدس وحمص","معكرونة وكسكس","دقيق وسميد","قهوة وشاي","معلبات","توابل","مياه ومشروبات","مواد تنظيف"};
    final String[] expenses = {"فاتورة الكهرباء","فاتورة الإنترنت","الكراء","الألبسة","زيارة طبيب","أدوية","أخرى"};
    final String[] income = {"الراتب الشهري","مدخول آخر"};
    final String[] sewing = {"مدخول الخياطة","مصاريف الخياطة","دين للزبون","دين عليّ"};
    final String[] debts = {"دين لي عند شخص","دين عليّ لشخص","تسديد دين"};
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        if (db.getPin() == null) setupPin(); else askPin();
    }
    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(10),dp(8),dp(10),dp(8)); t.setGravity(Gravity.RIGHT); return t;
    }
    EditText edit(String hint, boolean number) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextSize(16);
        e.setInputType(number ? InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_TEXT);
        return e;
    }
    void setupPin(){
        final EditText p=edit("أنشئ رمزاً سرياً من 4 أرقام أو أكثر",true);
        new AlertDialog.Builder(this).setTitle("مرحباً بك في حساباتي").setMessage("أنشئ رمز PIN لحماية بياناتك").setView(p)
          .setCancelable(false).setPositiveButton("حفظ", (d,w)->{
            String v=p.getText().toString(); if(v.length()<4){ setupPin(); return; }
            db.setPin(hash(v)); showHome();
          }).show();
    }
    void askPin(){
        final EditText p=edit("أدخل الرمز السري",true);
        new AlertDialog.Builder(this).setTitle("حساباتي محمي").setView(p).setCancelable(false)
          .setPositiveButton("دخول",(d,w)->{ if(hash(p.getText().toString()).equals(db.getPin())) showHome(); else { Toast.makeText(this,"الرمز غير صحيح",Toast.LENGTH_LONG).show(); askPin(); } }).show();
    }
    String hash(String s){
        try { byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8")); StringBuilder x=new StringBuilder(); for(byte a:b)x.append(String.format(Locale.US,"%02x",a)); return x.toString(); }
        catch(Exception e){return s;}
    }
    void showHome(){
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(244,247,250));
        TextView header=text("حساباتي  |  إدارة الأموال ومصاريف المنزل",20,Color.WHITE);
        header.setBackgroundColor(Color.rgb(16,34,56)); header.setGravity(Gravity.CENTER); root.addView(header);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setPadding(dp(12),dp(12),dp(12),dp(24)); content.setOrientation(1); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); render();
    }
    void button(String label, Runnable action){
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        content.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(v->action.run());
    }
    void render(){
        content.removeAllViews();
        TextView title=text(current,22,Color.rgb(20,45,65)); content.addView(title);
        if(current.equals("الرئيسية")){
            double balance=db.sum("دخل")-db.sum("مصروف");
            double salaryLeft=db.sumCategory("دخل","الراتب الشهري")-db.sumHomeExpenses();
            content.addView(text(String.format(Locale.US,"المتبقي من الراتب بعد الاقتطاعات: %.2f دج",salaryLeft),20,Color.rgb(20,120,90)));
            content.addView(text(String.format(Locale.US,"الرصيد العام المسجل: %.2f دج",balance),18,Color.rgb(20,80,120)));
            content.addView(text(String.format(Locale.US,"إجمالي المداخيل: %.2f دج",db.sum("دخل")),16,Color.DKGRAY));
            content.addView(text(String.format(Locale.US,"إجمالي المصروفات: %.2f دج",db.sum("مصروف")),16,Color.DKGRAY));
            for(String s:sections) button(s,()->open(s));
            button("سجل كل العمليات",()->open("السجل"));
        } else if(current.equals("الخزينة")) {
            content.addView(text(String.format(Locale.US,"الراتب المسجل: %.2f دج",db.sumCategory("دخل","الراتب الشهري")),17,Color.DKGRAY));
            content.addView(text(String.format(Locale.US,"الاقتطاعات من الراتب: %.2f دج",db.sumHomeExpenses()),17,Color.DKGRAY));
            content.addView(text(String.format(Locale.US,"المتبقي من الراتب: %.2f دج",db.sumCategory("دخل","الراتب الشهري")-db.sumHomeExpenses()),20,Color.rgb(20,120,90)));
            for(String c:income) button("إضافة "+c,()->addDialog("دخل",c));
            button("عرض سجل الخزينة",()->list("دخل"));
        } else if(current.equals("المصروفات")) {
            for(String c:expenses) button("إضافة: "+c,()->addDialog("مصروف",c));
            button("عرض المصروفات",()->list("مصروف"));
        } else if(current.equals("الخضر والفواكه")) {
            button("الخضر",()->chooseItems(vegetables,"مصروف","خضر"));
            button("الفواكه",()->chooseItems(fruits,"مصروف","فواكه"));
            button("إضافة صنف جديد",()->addCustomDialog("خضر وفواكه"));
            button("سجل مشتريات الخضر والفواكه",()->listCategory("خضر","فواكه","خضر وفواكه"));
        } else if(current.equals("اللحوم والدجاج")) {
            chooseItems(meats,"مصروف","لحوم ودجاج");
            button("إضافة صنف جديد",()->addCustomDialog("لحوم ودجاج"));
            button("عرض المشتريات",()->listCategory("لحوم ودجاج"));
        } else if(current.equals("المواد الغذائية")) {
            chooseItems(foods,"مصروف","مواد غذائية");
            button("إضافة صنف جديد",()->addCustomDialog("مواد غذائية"));
            button("عرض المشتريات",()->listCategory("مواد غذائية"));
        } else if(current.equals("الخياطة")) {
            for(String c:sewing) button("إضافة "+c,()->addDialog(c.contains("مدخول")?"دخل":"مصروف",c));
            button("سجل الخياطة",()->listAllCategory("خياطة"));
        } else if(current.equals("الديون")) {
            for(String c:debts) button("إضافة "+c,()->addDialog(c.equals("تسديد دين")?"مصروف":"دين",c));
            button("عرض سجل الديون",()->list("دين"));
        } else if(current.equals("السجل")) listAll();
        button("العودة للرئيسية",()->open("الرئيسية"));
    }
    void open(String s){current=s;render();}
    void chooseItems(String[] items,String type,String group){
        for(String item:items) button(item,()->addDialog(type,item+" ("+group+")"));
    }
    void addCustomDialog(String group){
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(8),0,dp(8),0); box.setOrientation(1);
        EditText name=edit("اسم الصنف الجديد",false); box.addView(name);
        EditText amount=edit("السعر / المبلغ بالدينار الجزائري (دج)",true); box.addView(amount);
        EditText quantity=edit("الكمية (اختياري)",true); box.addView(quantity);
        EditText note=edit("ملاحظة (اختياري)",false); box.addView(note);
        new AlertDialog.Builder(this).setTitle("إضافة صنف جديد — "+group).setView(box).setNegativeButton("إلغاء",null)
          .setPositiveButton("حفظ",(d,w)->{
            String item=name.getText().toString().trim();
            try {
              double price=Double.parseDouble(amount.getText().toString());
              if(item.isEmpty()) throw new Exception();
              String q=quantity.getText().toString().trim();
              String n=(q.isEmpty()?"":"الكمية: "+q+" | ")+note.getText().toString();
              db.add("مصروف",item+" ("+group+")",price,n);
              Toast.makeText(this,"تمت إضافة الصنف والسعر",Toast.LENGTH_SHORT).show(); render();
            } catch(Exception e){Toast.makeText(this,"أدخل اسم الصنف والسعر بشكل صحيح",Toast.LENGTH_SHORT).show();}
          }).show();
    }
    void addDialog(String type,String category){
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(8),0,dp(8),0); box.setOrientation(1);
        EditText amount=edit("السعر / المبلغ بالدينار الجزائري (دج)",true); box.addView(amount);
        EditText note=edit("ملاحظة أو اسم الشخص (اختياري)",false); box.addView(note);
        EditText qty=edit("الكمية (اختياري)",true);
        if(category.contains("خضر")||category.contains("فواكه")||category.contains("لحوم")||category.contains("مواد غذائية")) box.addView(qty);
        new AlertDialog.Builder(this).setTitle(category).setView(box).setNegativeButton("إلغاء",null)
          .setPositiveButton("حفظ",(d,w)->{
            try {
              double a=Double.parseDouble(amount.getText().toString());
              String n=note.getText().toString();
              if(category.contains("خضر")||category.contains("فواكه")||category.contains("لحوم")||category.contains("مواد غذائية")){
                  // Store optional quantity alongside the note for each household purchase.
                  // The entered amount is the purchase price in DZD.
              }
              db.add(type,category,a,n);
              Toast.makeText(this,"تم حفظ العملية على الهاتف",Toast.LENGTH_SHORT).show(); render();
            } catch(Exception e){Toast.makeText(this,"أدخل مبلغاً صحيحاً",Toast.LENGTH_SHORT).show();}
          }).show();
    }
    void list(String type){ showList(type,null); }
    void listCategory(String... cats){ showList("مصروف",cats); }
    void listAllCategory(String c){ showList(null,new String[]{c}); }
    void showList(String type,String[] cats){
        content.removeAllViews(); content.addView(text("العمليات المسجلة",20,Color.BLACK));
        Cursor c=db.rows(type,cats);
        if(c.getCount()==0) content.addView(text("لا توجد عمليات مسجلة بعد",16,Color.GRAY));
        while(c.moveToNext()){
            content.addView(text(c.getString(2)+" — "+c.getString(3)+" دج\n"+c.getString(4)+"\n"+c.getString(5),15,Color.DKGRAY));
            View line=new View(this); line.setBackgroundColor(Color.LTGRAY); content.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        c.close(); button("العودة",()->render());
    }
    void listAll(){ showList(null,null); }
    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"hisabati.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE ops(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,category TEXT,amount REAL,note TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP)");
            d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        void add(String t,String cat,double a,String n){ContentValues v=new ContentValues();v.put("type",t);v.put("category",cat);v.put("amount",a);v.put("note",n);getWritableDatabase().insert("ops",null,v);}
        double sum(String type){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM ops WHERE type=?",new String[]{type});c.moveToFirst();double x=c.getDouble(0);c.close();return x;}
        double sumCategory(String type,String category){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM ops WHERE type=? AND category LIKE ?",new String[]{type,"%"+category+"%"});c.moveToFirst();double x=c.getDouble(0);c.close();return x;}
        double sumHomeExpenses(){
            Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM ops WHERE type='مصروف' AND category NOT LIKE '%خياطة%'",null);
            c.moveToFirst();double x=c.getDouble(0);c.close();return x;
        }
        Cursor rows(String type,String[] cats){
            String q="SELECT id,type,category,amount,note,created FROM ops"; java.util.ArrayList<String> args=new java.util.ArrayList<>(); boolean where=false;
            if(type!=null){q+=" WHERE type=?";args.add(type);where=true;}
            if(cats!=null&&cats.length>0){q+=where?" AND ":" WHERE ";q+="(";for(int i=0;i<cats.length;i++){if(i>0)q+=" OR ";q+="category LIKE ?";args.add("%"+cats[i]+"%");}q+=")";}
            q+=" ORDER BY id DESC"; return getReadableDatabase().rawQuery(q,args.toArray(new String[0]));
        }
        void setPin(String p){ContentValues v=new ContentValues();v.put("k","pin");v.put("v",p);getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
        String getPin(){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k='pin'",null);String x=null;if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    }
}
